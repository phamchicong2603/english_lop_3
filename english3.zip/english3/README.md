# English Garden — Tiếng Anh 3, tập 1

Mở `index.html` để luyện tập. Chỉ cần một file này, không cần thư viện, tài khoản hoặc máy chủ. Có 246 câu hỏi tự biên soạn bổ trợ theo Global Success: Starter, Unit 1–10, Review 1–2. Ngân hàng câu hỏi và đáp án được xáo trộn; các phần Unit/Lesson được phân bổ trước khi chọn ngẫu nhiên để tránh một lượt chỉ tập trung vào một phần.

## Đưa lên GitHub để mở trên điện thoại

1. Đăng nhập GitHub, tạo một repository mới, chẳng hạn `english-garden-3`. Chọn Public nếu dùng GitHub Pages miễn phí cho kho công khai.
2. Chọn **Add file → Upload files**, tải `index.html` trong thư mục này lên **gốc repository**, rồi bấm **Commit changes**. Không tải thư mục `reference` (ảnh sách dùng để đối chiếu) lên.
3. Vào **Settings → Pages → Build and deployment**. Chọn **Deploy from a branch**, chọn nhánh chứa file vừa tải (thường là `main`) và thư mục **/(root)**. Bấm **Save**.
4. Chờ GitHub triển khai xong. Mở đường dẫn trang được GitHub hiển thị trên điện thoại. Đường dẫn thường có dạng `https://TEN-TAI-KHOAN.github.io/english-garden-3/`. Xem [hướng dẫn GitHub Pages chính thức](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

Nếu repository đã có website, đặt file trong thư mục riêng để tránh ghi đè trang chủ. Việc chỉ xem file HTML trong giao diện GitHub không chạy website; cần mở liên kết GitHub Pages.

## Cách dùng cho trẻ

- Bắt đầu với Unit trẻ đã học, chọn Lesson và 10 câu. Không ép thời gian.
- Lesson 1: từ vựng và mẫu câu làm quen; Lesson 2: hội thoại và vận dụng; Lesson 3: nghe, nhận biết chữ đầu và đọc hiểu. Đây là cách phân nhóm bài bổ trợ; không phải bản sao từng hoạt động của sách. Starter được chia thành các phần luyện số và chữ; Review dùng lại ngân hàng của nhóm Unit tương ứng.
- Cho trẻ giải thích vì sao chọn, đọc lời giải rồi nói lại câu đúng. Dùng nút “Luyện câu sai” cho lượt tiếp theo.
- Khuyến khích viết lại một câu đúng trong vở. Phần đọc theo không thu âm hoặc tự chấm phát âm.
- Âm thanh là giọng tổng hợp của trình duyệt, cần giọng tiếng Anh trên thiết bị và có thể cần mạng tùy thiết bị. Không phải bản thu sách. Nếu không có âm thanh, người lớn bấm “Xem lời nghe” để đọc giúp trẻ.
- Tiến độ chỉ lưu trên trình duyệt hiện tại; không đồng bộ giữa điện thoại và máy tính. Việc xóa dữ liệu trình duyệt sẽ xóa tiến độ. Khi trình duyệt chặn lưu trữ, bài tập vẫn chạy nhưng không lưu tiến độ lâu dài.

## Nội dung và nguồn

Đối chiếu Book map trang 4–5 và ba Lesson của Unit 1 trong sách người dùng cung cấp: *Tiếng Anh 3 – Global Success, sách học sinh, tập một*. Nội dung câu hỏi là bài luyện bổ trợ tự biên soạn theo từ vựng và mẫu câu trong Book map; không tái xuất bản ảnh sách, bài hát hoặc bản thu âm. Trắc nghiệm không thay thế hoạt động giao tiếp trực tiếp và luyện viết tự do.

`index.html` là sản phẩm chạy độc lập. `build.py` và `template.html` là nguồn để chỉnh sửa và tạo lại file bằng Python, không cần tải lên để website hoạt động.
