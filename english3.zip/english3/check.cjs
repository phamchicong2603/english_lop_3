const {chromium}=require('C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 const page=await browser.newPage({viewport:{width:390,height:844}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8765');
 const report=await page.evaluate(()=>{const ids=new Set();for(const q of DATA.questions){if(ids.has(q.id))throw Error('Duplicate id');ids.add(q.id);if(new Set(q.options).size!==4||!q.options.includes(q.answer))throw Error('Bad options '+q.id)}for(let u=1;u<=10;u++)for(let l=1;l<=3;l++)if(!pool(String(u),String(l)).length)throw Error('Empty lesson');for(let i=0;i<30;i++){const a=sample(pool('all'),20);if(new Set(a.map(q=>q.id)).size!==a.length)throw Error('Repeated questions')}if(pool('review1').some(q=>q.unit<1||q.unit>5)||pool('review2').some(q=>q.unit<6||q.unit>10))throw Error('Review coverage');return{count:DATA.questions.length,overflow:document.documentElement.scrollWidth>innerWidth}});
 assert.equal(report.count,246);assert.equal(report.overflow,false);
 await page.screenshot({path:'english3/mobile.png',fullPage:true});
 await page.selectOption('#scope','1');await page.click('#start');
 for(let i=0;i<10;i++){
   const answer=await page.evaluate(()=>queue[index].answer);
   const opts=page.locator('#options button');let picked=0;
   for(let j=0;j<await opts.count();j++){const value=await opts.nth(j).locator('span').innerText();if((i===0&&value!==answer)||(i>0&&value===answer)){await opts.nth(j).click();picked++;break}}
   assert.equal(picked,1);await page.click('#next');
 }
 assert.equal(await page.locator('.result-score').innerText(),'9/10');
 const stored=await page.evaluate(()=>JSON.parse(localStorage.getItem(KEY)));assert.equal(stored.wrong.length,1);assert.equal(stored.sessions,1);
 await page.reload();await page.click('#mistakes');
 assert.equal(await page.locator('#position').innerText(),'Câu 1 / 1');
 const answer=await page.evaluate(()=>queue[index].answer);
 await page.locator('#options button').filter({has:page.locator('span',{hasText:answer})}).first().click();await page.click('#next');
 assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem(KEY)).wrong.length),0);
 await page.setViewportSize({width:1280,height:900});await page.reload();await page.screenshot({path:'english3/desktop.png',fullPage:true});assert.deepEqual(errors,[]);
 await page.goto('file:///'+require('node:path').resolve('english3/index.html').replaceAll('\\','/'));await page.click('#start');assert.equal(await page.locator('#options button').count(),4);
 console.log(JSON.stringify({questions:report.count,mobileOverflow:report.overflow,grading:'9/10 after one intentional error',mistakeRetry:'passed',persistence:'passed',standaloneHtml:'passed',browserErrors:errors}));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
